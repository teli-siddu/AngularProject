import { Component, SimpleChanges, AfterViewInit, OnInit } from '@angular/core';

import { from, Observable } from 'rxjs';
import { Router, NavigationStart, NavigationEnd, NavigationCancel } from '@angular/router';
import { LoadingScreenService } from './shared/services/loading-screen.service';
import { AuthenticationService } from './services/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit, OnInit {
  title = 'EmployeeManagement';

  isAuthenticated$: Observable<boolean>;
  collapseNavMenu: boolean = true;
  navMenucssClass: string = this.collapseNavMenu ? "hide-navbar" : null;
  width: string = "wt-60"

  /**
   *
   */
  constructor(private router: Router, private loadingScreenService: LoadingScreenService, private authenticationService: AuthenticationService) {
    this.isAuthenticated$ = this.authenticationService.isAuthenticated();

  }


  ToggleNavMenuClick() {
    this.navMenucssClass = this.navMenucssClass == "hide-navbar" ? "" : "hide-navbar";

  }
  ToggleWidthClick() {
    //  alert("sdfsadsa");
    if (this.width == "wt-60") {
      this.width = "wt-180";
    }
    else {
      this.width = "wt-60";
    }
  }

  ngOnInit() {

    // this.router.events.subscribe((event) => {

    // })
    // this.loadingScreenService.start("sadfsdfsd")
    // alert("navigation started")
  }
  ngAfterViewInit() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        // this.loadingScreenService.start("sadfsdfsd")
      }
      else if (
        event instanceof NavigationEnd ||
        event instanceof NavigationCancel
      ) {
        this.loadingScreenService.stop();

      }
    })

    // alert("navigation ended")
  }
}
