export class ReturnResult {
    Succeeded: boolean;
    Error: string;
}