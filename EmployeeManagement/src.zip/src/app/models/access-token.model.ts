export class AccessToken {

    Token: string;
    TokenExpiration: string;
    RefreshToken: string;


}